﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        internal double? n1, n2;
        public double result = 0;
        public string s = "";
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
           n1 = Convert.ToDouble(textBox1.Text);
        
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
             n2 = Convert.ToDouble(textBox2.Text);
     
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double add = double(n1 + n2);
            result = add;
           s = (sender as Button).Text;
           MessageBox.Show(s + ":" + result);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double sub = (n1 > n2) ? double(n1 - n2) : double(n2 - n1);
            result = sub;
          s = (sender as Button).Text;
          MessageBox.Show(s + ":" + result);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double  mul = n1 * n2;
            result = mul;
             s = (sender as Button).Text;
             MessageBox.Show(s + ":" + result);
        }

        private void button4_Click(object sender, EventArgs e)
        {
           decimal div=0;
           if (n2 != 0 )
           {
               div = (decimal)n1 / (decimal)n2;
               result = (double)div;
               s = (sender as Button).Text;
               MessageBox.Show(s + ":" + result);
           }
           else
               MessageBox.Show("Can't divide by zero");

              
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Action<Control.ControlCollection> func = null;

            func = (controls) =>
            {
                foreach (Control control in controls)
                    if (control is TextBox)
                        (control as TextBox).Clear();
                    else
                        func(control.Controls);
            };

            func(Controls);
        }

       
    }
}
